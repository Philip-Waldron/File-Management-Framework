package Memento;

public abstract class Memento {}
