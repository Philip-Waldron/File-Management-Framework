package core;
import UI.loginUI;
public class test{
    public static void main (String []argus){

        loginUI ui=new loginUI();
        ui.show();

    }
}