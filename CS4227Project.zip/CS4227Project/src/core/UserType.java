package core;

public interface UserType {

    public int UserNumberGeneration();
}

