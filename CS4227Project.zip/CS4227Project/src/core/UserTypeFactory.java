package core;

import java.awt.Window.Type;

public interface UserTypeFactory {
    UserType CreateUserTypeFactory();
}