package UI;

public class TeacherHomePageUI implements UI {
    public TeacherHomePageUI(){


    }
    @Override
    public void show() {
        // TODO Auto-generated method stub

    }

    @Override
    public void hide() {
        // TODO Auto-generated method stub

    }

}
