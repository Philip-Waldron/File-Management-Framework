package UI;

public interface UI {

    public void show();
    public void hide();
}
