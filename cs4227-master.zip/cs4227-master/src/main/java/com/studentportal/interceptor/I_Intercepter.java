package com.studentportal.interceptor;

import com.studentportal.interceptor.ContextFile;

public interface I_Intercepter {
    void interceptExecute(ContextFile uiContext);
}


