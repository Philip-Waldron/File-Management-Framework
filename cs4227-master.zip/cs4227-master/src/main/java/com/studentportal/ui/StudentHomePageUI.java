package com.studentportal.ui;

public class StudentHomePageUI {
}
