package com.studentportal.ui;

public class TeacherHomePageUI extends Ui {
    public TeacherHomePageUI(){


    }
}
