package com.studentportal.ui;

public class CourseManagementUi {
}
