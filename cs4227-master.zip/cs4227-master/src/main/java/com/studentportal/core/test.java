package com.studentportal.core;
import com.studentportal.ui.LoginUI;
public class test{
    public static void main (String []argus){

        LoginUI ui=new LoginUI();
        ui.show();

    }
}