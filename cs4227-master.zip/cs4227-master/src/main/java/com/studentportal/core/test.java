package com.studentportal.core;
import com.studentportal.ui.loginUI;
public class test{
    public static void main (String []argus){

        loginUI ui=new loginUI();
        ui.show();

    }
}