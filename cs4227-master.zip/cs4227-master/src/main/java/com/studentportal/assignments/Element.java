package com.studentportal.assignments;

public interface Element {
    String accept(Visitor v);
}
