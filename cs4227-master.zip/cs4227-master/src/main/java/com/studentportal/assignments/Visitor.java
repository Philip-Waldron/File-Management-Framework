package com.studentportal.assignments;

public interface Visitor {
    String visit(QuizQuestion question);
}
