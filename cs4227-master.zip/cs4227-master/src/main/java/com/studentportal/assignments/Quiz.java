//package com.studentportal.assignments;
//
//public class Quiz {
//
//    private int id;
//    private int numberOfQuestions;
//    private String[][] questionsAndAnswers;
//    String[] answers;
//    private QuizAssignment assignment;
//
//    public Quiz(int id, int numberOfQuestions, String[][] questionsAndAnswers,
//                String[] answers, QuizAssignment assignment) {
//        this.id = id;
//        this.numberOfQuestions = numberOfQuestions;
//        this.questionsAndAnswers = questionsAndAnswers;
//        this.answers = answers;
//        this.assignment = assignment;
//    }
//
//    public int getId() {
//        return id;
//    }
//
//    public void setId(int id) {
//        this.id = id;
//    }
//
//    public int getNumberOfQuestions() {
//        return numberOfQuestions;
//    }
//
//    public void setNumberOfQuestions(int numberOfQuestions) {
//        this.numberOfQuestions = numberOfQuestions;
//    }
//
//    public String[][] getQuestionsAndAnswers() {
//        return questionsAndAnswers;
//    }
//
//    public void setQuestionsAndAnswers(String[][] questionsAndAnswers) {
//        this.questionsAndAnswers = questionsAndAnswers;
//    }
//
//    public String[] getAnswers() {
//        return answers;
//    }
//
//    public void setAnswers(String[] answers) {
//        this.answers = answers;
//    }
//
//    public QuizAssignment getAssignment() {
//        return assignment;
//    }
//
//    public void setAssignment(QuizAssignment assignment) {
//        this.assignment = assignment;
//    }
//}
