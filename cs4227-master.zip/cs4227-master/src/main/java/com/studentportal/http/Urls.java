package com.studentportal.http;

public class Urls {
    public static final String getDocument = "http://localhost:9990/file-mgmt/document/download/";
}
