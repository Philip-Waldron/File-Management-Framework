package com.studentportal.http.courses;

public enum CourseUpdateType {
    add,
    remove
}
