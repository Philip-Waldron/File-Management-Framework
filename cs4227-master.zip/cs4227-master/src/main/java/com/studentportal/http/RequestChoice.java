package com.studentportal.http;

public enum RequestChoice {
    DOCUMENT,
    QUIZ,
    PROJECT,
    USER,
    COURSE
}
