package com.studentportal.reminders.Senders;

public interface ReminderSender {
    public void sendReminder(String title, String body);
}
