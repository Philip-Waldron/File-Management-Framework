package com.studentportal.reminders.ReminderTypes;


public enum ReminderType {
    ASSIGNMENT,
    MEETING
}
