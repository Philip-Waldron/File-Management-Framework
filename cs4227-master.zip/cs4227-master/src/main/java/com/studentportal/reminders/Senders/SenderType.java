package com.studentportal.reminders.Senders;

/**
 * Created by Robert Mccahill on 18/10/2017.
 */
public enum  SenderType {
    EMAIL,
    PORTAL,
    SMS
}
