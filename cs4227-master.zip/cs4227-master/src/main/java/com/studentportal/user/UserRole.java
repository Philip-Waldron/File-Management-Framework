package com.studentportal.user;

public enum UserRole {
    TEACHER,
    STUDENT,
    ADMIN
}
