package com.studentportal.Memento;

public interface Memento {}
