package com.studentportal.announcement;

public interface Memento {}
